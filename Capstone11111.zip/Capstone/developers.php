<?php include('header_dashboard.php'); ?>
    <body id="class_div">
		<?php include('navbar_about.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span12" id="content">
                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
								<div class="navbar navbar-inner block-header">
									<div id="" class="muted pull-right"><a href="index.php"><i class="icon-arrow-left"></i> Back</a></div>
								</div>
                            <div class="block-content collapse in">
							<h3>Developers</h3>
							<hr>
                                <div class="span3">
										<center>
										<img id="developers" src="admin/images/jkev.jpg" class="img-circle">
										<hr>
										<p>Name: John Kevin Lorayna</p>
										<p>Address: Bago City</p>
										<p>Email: jkevlorayna@gmail.com</p>
										<p>Position: Programmer</p>
										</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/jelyn.jpg" class="img-circle">
								<hr>
																				<p>Name: Jorgielyn Serfino</p>

										<p>Address: Bago City</p>
										<p>Email: jkevlorayna@gmail.com</p>
										<p>Position: Programmer</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/jorge.jpg" class="img-circle">
								<hr>
												<p>Name: Jorgielyn Serfino</p>
										<p>Address: Ilog</p>
										<p>Email: jkevlorayna@gmail.com</p>
										<p>Position: Project Manager</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/mich.jpg" class="img-circle">
								<hr>
												<p>Name: John Kevin Lorayna</p>
										<p>Address: Talisay City</p>
										<p>Email: jkevlorayna@gmail.com</p>
										<p>Position: Project Manager</p>
								</center>
								</div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		
        </div>
		<?php include('script.php'); ?>
    </body>
</html>