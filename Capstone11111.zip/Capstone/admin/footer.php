<div class="pull-right">
		<footer>
           
        <footer>
</div>