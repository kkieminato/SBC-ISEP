<!-- Modal -->
<div id="myModal1" class="modal hide fade " tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-header">
		<button type="button" class="close pull-right" data-dismiss="modal" aria-hidden="true"> &nbsp; x &nbsp;</button>
		<h3 id="myModalLabel">Create Class</h3>
	</div>
		<div class="modal-body">
					
							<center>	
                            <?php include('teacher_right_sidebar.php') ?>
							</center>			
					
		</div>
					
				
</div>
<!-- end  Modal -->