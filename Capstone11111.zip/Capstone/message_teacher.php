<li>
							<a tabindex="-1" href="#myModal2" class="pull-right" data-toggle="modal"><img src="" class="icon-comment icon-large" alt=""></a>
							<?php include('message_teacher_sidebar.php'); ?>
						</li>
						<li>
							<a href=""><img src="" class="icon-globe icon-large" alt=""></a>
							
						</li>